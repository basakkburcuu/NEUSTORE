import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { RNlerPage } from '../rnler/rnler';

@Component({
  selector: 'page-ana-sayfa',
  templateUrl: 'ana-sayfa.html'
})
export class AnaSayfaPage {

  constructor(public navCtrl: NavController) {
  }
  goToRNler(params){
    if (!params) params = {};
    this.navCtrl.push(RNlerPage);
  }
}
