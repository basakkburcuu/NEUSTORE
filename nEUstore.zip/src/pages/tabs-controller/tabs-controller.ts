import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { SepetimPage } from '../sepetim/sepetim';
import { RNlerPage } from '../rnler/rnler';
import { AyarlarPage } from '../ayarlar/ayarlar';
import { YeniYelikGiriPage } from '../yeni-yelik-giri/yeni-yelik-giri';
import { AnaSayfaPage } from '../ana-sayfa/ana-sayfa';
import { YardMPage } from '../yard-m/yard-m';
import { SepetimPage } from '../sepetim/sepetim';
import { FavorilerimPage } from '../favorilerim/favorilerim';
import { AyarlarPage } from '../ayarlar/ayarlar';
import { AnaSayfaPage } from '../ana-sayfa/ana-sayfa';

@Component({
  selector: 'page-tabs-controller',
  templateUrl: 'tabs-controller.html'
})
export class TabsControllerPage {

  tab1Root: any = YardMPage;
  tab2Root: any = SepetimPage;
  tab3Root: any = FavorilerimPage;
  tab4Root: any = AyarlarPage;
  tab5Root: any = AnaSayfaPage;
  constructor(public navCtrl: NavController) {
  }
  goToSepetim(params){
    if (!params) params = {};
    this.navCtrl.push(SepetimPage);
  }goToRNler(params){
    if (!params) params = {};
    this.navCtrl.push(RNlerPage);
  }goToAyarlar(params){
    if (!params) params = {};
    this.navCtrl.push(AyarlarPage);
  }goToYeniYelikGiri(params){
    if (!params) params = {};
    this.navCtrl.push(YeniYelikGiriPage);
  }goToAnaSayfa(params){
    if (!params) params = {};
    this.navCtrl.push(AnaSayfaPage);
  }
}
