import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { YeniYelikGiriPage } from '../yeni-yelik-giri/yeni-yelik-giri';
import { AnaSayfaPage } from '../ana-sayfa/ana-sayfa';
import { RNlerPage } from '../rnler/rnler';

@Component({
  selector: 'page-ayarlar',
  templateUrl: 'ayarlar.html'
})
export class AyarlarPage {

  constructor(public navCtrl: NavController) {
  }
  goToYeniYelikGiri(params){
    if (!params) params = {};
    this.navCtrl.push(YeniYelikGiriPage);
  }goToAnaSayfa(params){
    if (!params) params = {};
    this.navCtrl.push(AnaSayfaPage);
  }goToRNler(params){
    if (!params) params = {};
    this.navCtrl.push(RNlerPage);
  }
}
