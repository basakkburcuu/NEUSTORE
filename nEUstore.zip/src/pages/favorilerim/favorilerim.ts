import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-favorilerim',
  templateUrl: 'favorilerim.html'
})
export class FavorilerimPage {

  constructor(public navCtrl: NavController) {
  }
  
}
