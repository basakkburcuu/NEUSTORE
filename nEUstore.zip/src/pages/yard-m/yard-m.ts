import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-yard-m',
  templateUrl: 'yard-m.html'
})
export class YardMPage {

  constructor(public navCtrl: NavController) {
  }
  
}
