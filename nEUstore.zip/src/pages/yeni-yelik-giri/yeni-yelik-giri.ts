import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { AnaSayfaPage } from '../ana-sayfa/ana-sayfa';
import { RNlerPage } from '../rnler/rnler';

@Component({
  selector: 'page-yeni-yelik-giri',
  templateUrl: 'yeni-yelik-giri.html'
})
export class YeniYelikGiriPage {

  constructor(public navCtrl: NavController) {
  }
  goToAnaSayfa(params){
    if (!params) params = {};
    this.navCtrl.push(AnaSayfaPage);
  }goToRNler(params){
    if (!params) params = {};
    this.navCtrl.push(RNlerPage);
  }
}
