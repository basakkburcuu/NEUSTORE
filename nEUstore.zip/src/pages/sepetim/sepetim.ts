import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { RNlerPage } from '../rnler/rnler';

@Component({
  selector: 'page-sepetim',
  templateUrl: 'sepetim.html'
})
export class SepetimPage {

  constructor(public navCtrl: NavController) {
  }
  goToRNler(params){
    if (!params) params = {};
    this.navCtrl.push(RNlerPage);
  }
}
