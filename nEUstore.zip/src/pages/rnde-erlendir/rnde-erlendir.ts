import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-rnde-erlendir',
  templateUrl: 'rnde-erlendir.html'
})
export class RNDeErlendirPage {

  constructor(public navCtrl: NavController) {
  }
  
}
