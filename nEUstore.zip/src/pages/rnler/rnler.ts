import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-rnler',
  templateUrl: 'rnler.html'
})
export class RNlerPage {

  constructor(public navCtrl: NavController) {
  }
  
}
