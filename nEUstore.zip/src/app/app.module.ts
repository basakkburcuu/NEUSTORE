import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { YardMPage } from '../pages/yard-m/yard-m';
import { SepetimPage } from '../pages/sepetim/sepetim';
import { RNDeErlendirPage } from '../pages/rnde-erlendir/rnde-erlendir';
import { FavorilerimPage } from '../pages/favorilerim/favorilerim';
import { TabsControllerPage } from '../pages/tabs-controller/tabs-controller';
import { AyarlarPage } from '../pages/ayarlar/ayarlar';
import { YeniYelikGiriPage } from '../pages/yeni-yelik-giri/yeni-yelik-giri';
import { AnaSayfaPage } from '../pages/ana-sayfa/ana-sayfa';
import { RNlerPage } from '../pages/rnler/rnler';


import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

@NgModule({
  declarations: [
    MyApp,
    YardMPage,
    SepetimPage,
    RNDeErlendirPage,
    FavorilerimPage,
    TabsControllerPage,
    AyarlarPage,
    YeniYelikGiriPage,
    AnaSayfaPage,
    RNlerPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    YardMPage,
    SepetimPage,
    RNDeErlendirPage,
    FavorilerimPage,
    TabsControllerPage,
    AyarlarPage,
    YeniYelikGiriPage,
    AnaSayfaPage,
    RNlerPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}